<script>
	import { Button } from "./index.ts";

	let { src, meta, example, code } = $props();

	$inspect('Example wrapper: ', { src, meta, example, code });

	let mode = $state('preview');
	let theme = $state('fluent');

    let githubUrl = $derived(`https://github.com/plantir/uikit/blob/main${meta.filename}`)
</script>



<div class="">
	<div class="border p-2 border-b-0 rounded-t-xl flex justify-between items-center border-base-300 bg-base-200">
		<div class="flex gap-2">
            <Button size="sm" variant={mode === 'code' ? null : "ghost"} color='primary' onclick={() => mode = 'code'}>
                Code
            </Button>
            <Button size="sm" variant={mode === 'preview' ? null : "ghost"} color='primary' onclick={() => mode = 'preview'}>
                Preview
            </Button>
		</div>
		<div class="flex gap-2">
			<select bind:value={theme}>
				<option value="fluent">Fluent</option>
				<option value="fluent-dark">Fluent Dark</option>
			</select>
            <Button href={githubUrl} class="invert" shape="square">
                <img src="/github.svg"/>
            </Button>
		</div>
	</div>
	<div class="border border-base-300 rounded-b-xl">
		{#if mode === 'preview'}
			<div data-theme={theme} class="p-16 flex items-center flex-col justify-center">
                <div>
                    {@render example()}
                </div>
			</div>
		{:else}
			<pre><code>{@render code()}</code></pre>
		{/if}
	</div>
</div>
