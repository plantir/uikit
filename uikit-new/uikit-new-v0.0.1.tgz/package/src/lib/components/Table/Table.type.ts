import type { Base, GlobalColor, GlobalSize } from '$lib/utils/El.types.js';

export type TableSize = GlobalSize;
export type TableColor = 'natural' | GlobalColor;
export interface Table extends Base {
	label?: string | undefined;
	value?: string;
	name?: string;
	size?: TableSize;
	disabled?: boolean;
	zebra?: boolean;
	hover?: boolean;
	pinHead?: boolean;
	pinCols?: boolean;
}
