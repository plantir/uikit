<script lang="ts">
	import El from '$lib/utils/El.svelte';
	import type { Breadcrumbs } from './Breadcrumbs.type.js';
	import type { GlobalColor, GlobalSize } from '$lib/utils/El.types.js';
	type $$Props = Breadcrumbs;
	let componentName = 'breadcrumbs';
	$: componentClass = {};
</script>

<!-- <span transition:fade> -->
<El {componentName} {componentClass} {...$$restProps}>
	<ul>
		<slot></slot>
	</ul>
</El>
<!-- </span> -->
