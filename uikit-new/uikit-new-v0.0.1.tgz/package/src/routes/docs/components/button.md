---
title: Button - Flowbite
description: Use the accordion component to show hidden information based on the collapse and expand state of the child elements using data attribute options
---

# Button

this is button example

```svelte example
<script>
    import {Button } from 'plantir-uikit'
</script>

<Button color="primary">Primary</Button>
```