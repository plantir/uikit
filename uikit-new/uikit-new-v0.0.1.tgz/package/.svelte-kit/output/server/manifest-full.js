export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.svg","github.svg"]),
	mimeTypes: {".svg":"image/svg+xml"},
	_: {
		client: {start:"_app/immutable/entry/start.CTXDmzqI.js",app:"_app/immutable/entry/app.DAVPUiAf.js",imports:["_app/immutable/entry/start.CTXDmzqI.js","_app/immutable/chunks/CKAGc0J7.js","_app/immutable/chunks/BhbwymIt.js","_app/immutable/chunks/BwmhT6Fb.js","_app/immutable/entry/app.DAVPUiAf.js","_app/immutable/chunks/C8LXNZYb.js","_app/immutable/chunks/BhbwymIt.js","_app/immutable/chunks/CW2yWOsH.js","_app/immutable/chunks/BMM7eCE_.js","_app/immutable/chunks/sBliGABq.js","_app/immutable/chunks/DvUPUVkR.js","_app/immutable/chunks/BwmhT6Fb.js","_app/immutable/chunks/CL95NEDQ.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/docs/components/[slug]",
				pattern: /^\/docs\/components\/([^/]+?)\/?$/,
				params: [{"name":"slug","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
