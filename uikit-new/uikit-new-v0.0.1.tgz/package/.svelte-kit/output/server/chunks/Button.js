import { U as sanitize_props, V as rest_props, a7 as element, X as bind_props, Y as slot, a3 as attributes, $ as clsx, W as spread_props } from "./index2.js";
import { uniq } from "lodash-es";
import { f as fallback } from "./context.js";
function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
const PREFIX = "ui-";
const ClassMerge = ({
  prefix,
  name,
  componentClass,
  staticClassess
}) => {
  prefix = prefix || PREFIX;
  const result = [];
  const pre = `${prefix}${name}`;
  result.push(pre);
  componentClass && Object.entries(componentClass).map(([key, value]) => {
    if (value == true) {
      result.push(`${pre}-${key}`);
    } else if (value && key != "") {
      result.push(`${pre}-${key}-${value}`);
    }
  });
  staticClassess && staticClassess != "" && result.push(...staticClassess.split(" "));
  return uniq(result).join(" ");
};
function El($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "componentName",
    "componentClass",
    "tag",
    "node",
    "use",
    "options",
    "role"
  ]);
  $$renderer.component(($$renderer2) => {
    const noop = () => {
    };
    let componentName = fallback($$props["componentName"], "El");
    let componentClass = fallback($$props["componentClass"], () => ({}), true);
    let tag = fallback($$props["tag"], () => $$restProps.href ? "a" : "div", true);
    let node = fallback($$props["node"], void 0);
    let use = fallback($$props["use"], noop);
    let options = fallback($$props["options"], () => ({}), true);
    let role = fallback($$props["role"], void 0);
    let frameClass;
    frameClass = ClassMerge({
      name: componentName,
      componentClass,
      staticClassess: $$sanitized_props.class
    });
    element(
      $$renderer2,
      tag,
      () => {
        $$renderer2.push(`${attributes({ role, ...$$restProps, class: clsx(frameClass) })}`);
      },
      () => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {}, null);
        $$renderer2.push(`<!--]-->`);
      }
    );
    bind_props($$props, { componentName, componentClass, tag, node, use, options, role });
  });
}
function Loading($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["type", "size", "color"]);
  let componentClass;
  let componentName = "loading";
  let type = fallback($$props["type"], "spinner");
  let size = fallback($$props["size"], void 0);
  let color = fallback($$props["color"], void 0);
  componentClass = {
    xs: size == "xs",
    sm: size == "sm",
    md: size == "md",
    lg: size == "lg",
    xl: size == "xl",
    spinner: type == "spinner",
    dots: type == "dots",
    ring: type == "ring",
    ball: type == "ball",
    bars: type == "bars",
    infinity: type == "infinity",
    primary: color == "primary",
    secondary: color == "secondary",
    accent: color == "accent",
    success: color == "success",
    warning: color == "warning",
    info: color == "info",
    error: color == "error",
    neutral: color == "neutral"
  };
  El($$renderer, spread_props([{ componentClass, componentName }, $$restProps]));
  bind_props($$props, { type, size, color });
}
function Button($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "disabled",
    "href",
    "loading",
    "wide",
    "active",
    "block",
    "size",
    "variant",
    "shape",
    "color"
  ]);
  let componentClass;
  let componentName = "button";
  let disabled = fallback($$props["disabled"], false);
  let href = fallback($$props["href"], "");
  let loading = fallback($$props["loading"], false);
  let wide = fallback($$props["wide"], false);
  let active = fallback($$props["active"], false);
  let block = fallback($$props["block"], false);
  let size = fallback($$props["size"], void 0);
  let variant = fallback($$props["variant"], void 0);
  let shape = fallback($$props["shape"], void 0);
  let color = fallback($$props["color"], void 0);
  componentClass = {
    wide,
    block,
    loading,
    active,
    outline: variant == "outline",
    glass: variant == "glass",
    link: variant == "link",
    ghost: variant == "ghost",
    square: shape == "square",
    circle: shape == "circle",
    xs: size == "xs",
    sm: size == "sm",
    md: size == "md",
    lg: size == "lg",
    xl: size == "xl",
    disabled: disabled || loading,
    primary: color == "primary",
    secondary: color == "secondary",
    accent: color == "accent",
    success: color == "success",
    info: color == "info",
    error: color == "error",
    warning: color == "warning",
    neutral: color == "neutral"
  };
  El($$renderer, spread_props([
    {
      tag: href ? "a" : "button",
      href: href ? href : void 0,
      componentName,
      componentClass
    },
    $$restProps,
    {
      children: ($$renderer2) => {
        if (loading) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<!--[-->`);
          slot($$renderer2, $$props, "loader", {}, () => {
            Loading($$renderer2, { size: "xs" });
          });
          $$renderer2.push(`<!--]-->`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<!--[-->`);
          slot($$renderer2, $$props, "default", {}, null);
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
  bind_props($$props, {
    disabled,
    href,
    loading,
    wide,
    active,
    block,
    size,
    variant,
    shape,
    color
  });
}
export {
  Button as B,
  ClassMerge as C,
  El as E,
  html as h
};
