import "clsx";
import { B as Button, h as html } from "./Button.js";
import { a1 as attr } from "./index2.js";
function ExampleWrapper($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { meta, example, code } = $$props;
    let mode = "preview";
    let theme = "fluent";
    let githubUrl = `https://github.com/plantir/uikit/blob/main${meta.filename}`;
    $$renderer2.push(`<div><div class="border p-2 border-b-0 rounded-t-xl flex justify-between items-center border-base-300 bg-base-200"><div class="flex gap-2">`);
    Button($$renderer2, {
      size: "sm",
      variant: mode === "code" ? null : "ghost",
      color: "primary",
      onclick: () => mode = "code",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->Code`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      size: "sm",
      variant: mode === "preview" ? null : "ghost",
      color: "primary",
      onclick: () => mode = "preview",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->Preview`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div> <div class="flex gap-2">`);
    $$renderer2.select({ value: theme }, ($$renderer3) => {
      $$renderer3.option({ value: "fluent" }, ($$renderer4) => {
        $$renderer4.push(`Fluent`);
      });
      $$renderer3.option({ value: "fluent-dark" }, ($$renderer4) => {
        $$renderer4.push(`Fluent Dark`);
      });
    });
    $$renderer2.push(` `);
    Button($$renderer2, {
      href: githubUrl,
      class: "invert",
      shape: "square",
      children: ($$renderer3) => {
        $$renderer3.push(`<img src="/github.svg"/>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div> <div class="border border-base-300 rounded-b-xl">`);
    if (mode === "preview") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div${attr("data-theme", theme)} class="p-16 flex items-center flex-col justify-center"><div>`);
      example($$renderer2);
      $$renderer2.push(`<!----></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<pre><code>`);
      code($$renderer2);
      $$renderer2.push(`<!----></code></pre>`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
  });
}
function Button_md___mdsvexample___0($$renderer) {
  Button($$renderer, {
    color: "primary",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Primary`);
    },
    $$slots: { default: true }
  });
}
const metadata = {
  "title": "Button - Flowbite",
  "description": "Use the accordion component to show hidden information based on the collapse and expand state of the child elements using data attribute options"
};
const { title, description } = metadata;
function Button_md($$renderer) {
  $$renderer.push(`<h1>Button</h1> <p>this is button example</p> <div>`);
  {
    let example = function($$renderer2) {
      Button_md___mdsvexample___0($$renderer2);
    }, code = function($$renderer2) {
      $$renderer2.push(`${html(`<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>script</span><span class="token punctuation">></span></span><span class="token script"><span class="token language-javascript">
    <span class="token keyword">import</span> <span class="token punctuation">{</span>Button <span class="token punctuation">}</span> <span class="token keyword">from</span> <span class="token string">'plantir-uikit'</span>
</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>script</span><span class="token punctuation">></span></span>

<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>Button</span> <span class="token attr-name">color</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>primary<span class="token punctuation">"</span></span><span class="token punctuation">></span></span>Primary<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>Button</span><span class="token punctuation">></span></span>`)}`);
    };
    ExampleWrapper($$renderer, {
      meta: {
        "Wrapper": "$lib/ExampleWrapper.svelte",
        "filename": "/src/routes/docs/components/button.md",
        "example": true
      },
      example,
      code
    });
  }
  $$renderer.push(`<!----></div>`);
}
export {
  Button_md as default,
  metadata
};
