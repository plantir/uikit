

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.Dt18l1gX.js","_app/immutable/chunks/DvUPUVkR.js","_app/immutable/chunks/BhbwymIt.js","_app/immutable/chunks/BoxrHmcM.js","_app/immutable/chunks/BMM7eCE_.js","_app/immutable/chunks/sBliGABq.js","_app/immutable/chunks/BZt0tXkI.js","_app/immutable/chunks/CKAGc0J7.js","_app/immutable/chunks/BwmhT6Fb.js"];
export const stylesheets = [];
export const fonts = [];
