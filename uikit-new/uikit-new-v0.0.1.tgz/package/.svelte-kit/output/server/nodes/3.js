import * as universal from '../entries/pages/docs/components/_slug_/_page.ts.js';

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/docs/components/_slug_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/docs/components/[slug]/+page.ts";
export const imports = ["_app/immutable/nodes/3.BqeuDibN.js","_app/immutable/chunks/C8LXNZYb.js","_app/immutable/chunks/BhbwymIt.js","_app/immutable/chunks/CW2yWOsH.js","_app/immutable/chunks/DvUPUVkR.js","_app/immutable/chunks/CMdJKWZy.js","_app/immutable/chunks/sBliGABq.js","_app/immutable/chunks/BZt0tXkI.js","_app/immutable/chunks/CKAGc0J7.js","_app/immutable/chunks/BwmhT6Fb.js"];
export const stylesheets = [];
export const fonts = [];
