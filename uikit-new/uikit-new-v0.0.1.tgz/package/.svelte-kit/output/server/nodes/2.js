

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.DG0RyUJH.js","_app/immutable/chunks/DvUPUVkR.js","_app/immutable/chunks/BhbwymIt.js","_app/immutable/chunks/BoxrHmcM.js","_app/immutable/chunks/CMdJKWZy.js","_app/immutable/chunks/sBliGABq.js","_app/immutable/chunks/BMM7eCE_.js","_app/immutable/chunks/CL95NEDQ.js","_app/immutable/chunks/CW2yWOsH.js","_app/immutable/chunks/BwmhT6Fb.js","_app/immutable/chunks/7dhnj_mk.js"];
export const stylesheets = ["_app/immutable/assets/2.642Dqt08.css"];
export const fonts = [];
