import { a6 as head, a1 as attr } from "../../../../../chunks/index2.js";
import { p as page } from "../../../../../chunks/index3.js";
import { e as escape_html } from "../../../../../chunks/context.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { data } = $$props;
    head("1692z01", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>${escape_html(data.content.metadata.title ?? `${page.params.slug} - Plantir UiKit`)}</title>`);
      });
      $$renderer3.push(`<meta name="description"${attr("content", data.content.metadata.description ?? `${page.params.slug} - Plantir UiKit`)}/>`);
    });
    $$renderer2.push(`<!---->`);
    data.content.default($$renderer2, {});
    $$renderer2.push(`<!---->`);
  });
}
export {
  _page as default
};
