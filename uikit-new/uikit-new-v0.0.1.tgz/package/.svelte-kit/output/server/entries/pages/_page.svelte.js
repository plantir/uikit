import { U as sanitize_props, V as rest_props, W as spread_props, X as bind_props, Y as slot, Z as store_get, _ as attr_class, $ as clsx, a0 as unsubscribe_stores, a1 as attr, a2 as sanitize_slots, a3 as attributes, a4 as ensure_array_like, a5 as attr_style, a6 as head } from "../../chunks/index2.js";
import { E as El, C as ClassMerge, h as html, B as Button } from "../../chunks/Button.js";
import { w as writable } from "../../chunks/index.js";
import { f as fallback, s as setContext, g as getContext, e as escape_html } from "../../chunks/context.js";
import "clsx";
let ctx$2 = {};
function setTabsContext(value) {
  return setContext(ctx$2, value);
}
function getTabsContext() {
  return getContext(ctx$2);
}
function Tabs($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["size", "variant", "color", "selected"]);
  $$renderer.component(($$renderer2) => {
    let componentClass;
    let componentName = "tabs";
    let size = fallback($$props["size"], void 0);
    let variant = fallback($$props["variant"], void 0);
    let color = fallback($$props["color"], void 0);
    let selected = fallback($$props["selected"], void 0);
    const ctx2 = setTabsContext({ selected: writable(selected) });
    ctx2.selected.subscribe((val) => {
      selected = val;
    });
    componentClass = {
      bordered: variant == "border",
      boxed: variant == "box",
      lifted: variant == "lift",
      xs: size == "xs",
      sm: size == "sm",
      md: size == "md",
      lg: size == "lg",
      xl: size == "xl",
      primary: color == "primary",
      secondary: color == "secondary",
      accent: color == "accent",
      success: color == "success",
      info: color == "info",
      error: color == "error",
      warning: color == "warning",
      neutral: color == "neutral"
    };
    El($$renderer2, spread_props([
      { componentName, componentClass },
      $$restProps,
      {
        children: ($$renderer3) => {
          $$renderer3.push(`<!--[-->`);
          slot($$renderer3, $$props, "default", {}, null);
          $$renderer3.push(`<!--]-->`);
        },
        $$slots: { default: true }
      }
    ]));
    bind_props($$props, { size, variant, color, selected });
  });
}
function TabItem($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["value", "title"]);
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let active, componentClass, tabContentClass;
    let componentName = "tab-item";
    let value = fallback($$props["value"], void 0);
    let title = fallback($$props["title"], void 0);
    const ctx2 = getTabsContext();
    const selected = ctx2?.selected ?? writable();
    active = store_get($$store_subs ??= {}, "$selected", selected) == value;
    componentClass = { active };
    tabContentClass = ClassMerge({ name: `${componentName}-content` });
    El($$renderer2, spread_props([
      { componentName, componentClass },
      $$restProps,
      {
        children: ($$renderer3) => {
          $$renderer3.push(`<!--[-->`);
          slot($$renderer3, $$props, "title", {}, () => {
            $$renderer3.push(`${escape_html(title)}`);
          });
          $$renderer3.push(`<!--]-->`);
        },
        $$slots: { default: true }
      }
    ]));
    $$renderer2.push(`<!----> `);
    if (active) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div${attr_class(clsx(tabContentClass))}><div><!--[-->`);
      slot($$renderer2, $$props, "default", {}, null);
      $$renderer2.push(`<!--]--></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { value, title });
  });
}
function Switch($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  $$renderer.component(($$renderer2) => {
    let componentClass, wrapperClass, elClass;
    let componentName = "switch";
    let label = fallback($$props["label"], void 0);
    let value = fallback($$props["value"], false);
    let disabled = fallback($$props["disabled"], false);
    let size = fallback($$props["size"], void 0);
    let color = fallback($$props["color"], void 0);
    componentClass = {
      xs: size == "xs",
      sm: size == "sm",
      md: size == "md",
      lg: size == "lg",
      xl: size == "xl",
      disabled,
      primary: color == "primary",
      secondary: color == "secondary",
      accent: color == "accent",
      success: color == "success",
      info: color == "info",
      error: color == "error",
      warning: color == "warning",
      neutral: color == "neutral"
    };
    wrapperClass = ClassMerge({
      name: `${componentName}-wrapper`,
      staticClassess: $$sanitized_props.class
    });
    elClass = ClassMerge({ name: componentName, componentClass });
    $$renderer2.push(`<label${attr_class(clsx(wrapperClass))}><input type="checkbox"${attr("disabled", disabled, true)}${attr("value", value)}${attr_class(clsx(elClass))}${attr("checked", value, true)}/> <!--[-->`);
    slot($$renderer2, $$props, "label", {}, () => {
      $$renderer2.push(`${escape_html(label)}`);
    });
    $$renderer2.push(`<!--]--></label>`);
    bind_props($$props, { label, value, disabled, size, color });
  });
}
function Avatar($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "size",
    "color",
    "shape",
    "mask",
    "ring",
    "text",
    "online",
    "offline"
  ]);
  let componentClass;
  let componentName = "avatar";
  let size = fallback($$props["size"], "md");
  let color = fallback($$props["color"], void 0);
  let shape = fallback($$props["shape"], void 0);
  let mask = fallback($$props["mask"], void 0);
  let ring = fallback($$props["ring"], false);
  let text = fallback($$props["text"], false);
  let online = fallback($$props["online"], false);
  let offline = fallback($$props["offline"], false);
  componentClass = {
    size,
    // xs: size == 'xs',
    // sm: size == 'sm',
    // md: size == 'md',
    // lg: size == 'lg',
    mask,
    // [`mask-${mask}`]: mask,
    online,
    offline,
    shape,
    // circle: shape == 'circle',
    // rounded: shape == 'rounded',
    // square: shape == 'square',
    ring,
    text,
    color
  };
  El($$renderer, spread_props([
    { componentName, componentClass },
    $$restProps,
    {
      children: ($$renderer2) => {
        $$renderer2.push(`<div><!--[-->`);
        slot($$renderer2, $$props, "default", {}, null);
        $$renderer2.push(`<!--]--></div>`);
      },
      $$slots: { default: true }
    }
  ]));
  bind_props($$props, { size, color, shape, mask, ring, text, online, offline });
}
function TextField($$renderer, $$props) {
  const $$slots = sanitize_slots($$props);
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "label",
    "placeholder",
    "value",
    "type",
    "disabled",
    "readonly",
    "size",
    "color",
    "hint",
    "state",
    "ghost",
    "inputClass",
    "node",
    "suggestions",
    "pattern"
  ]);
  $$renderer.component(($$renderer2) => {
    let componentClass, startWrapper, endWrapper, inputWrapper, wrapperClass, elClass, labelClass, hintClass, list;
    let componentName = "text-field";
    let label = fallback($$props["label"], void 0);
    let placeholder = fallback($$props["placeholder"], void 0);
    let value = fallback($$props["value"], "");
    let type = fallback($$props["type"], "text");
    let disabled = fallback($$props["disabled"], false);
    let readonly = fallback($$props["readonly"], false);
    let size = fallback($$props["size"], void 0);
    let color = fallback($$props["color"], void 0);
    let hint = fallback($$props["hint"], void 0);
    let state = fallback($$props["state"], void 0);
    let ghost = fallback($$props["ghost"], false);
    let inputClass = fallback($$props["inputClass"], "");
    let node = $$props["node"];
    let suggestions = fallback($$props["suggestions"], void 0);
    let pattern = fallback($$props["pattern"], "");
    let show_hint_pattern = false;
    componentClass = {
      xs: size == "xs",
      sm: size == "sm",
      md: size == "md",
      lg: size == "lg",
      xl: size == "xl",
      disabled,
      ghost,
      primary: color == "primary",
      secondary: color == "secondary",
      accent: color == "accent",
      success: color == "success",
      info: color == "info",
      error: color == "error",
      warning: color == "warning",
      neutral: color == "neutral",
      pattern: pattern !== "",
      "has-start": !!$$slots.start,
      "has-end": !!$$slots.end,
      "state-valid": state == "valid",
      "state-invalid": state == "invalid"
    };
    startWrapper = ClassMerge({ name: `${componentName}-start-wrapper` });
    endWrapper = ClassMerge({ name: `${componentName}-end-wrapper` });
    inputWrapper = ClassMerge({ name: `${componentName}-input-wrapper` });
    wrapperClass = ClassMerge({
      name: `${componentName}-wrapper`,
      staticClassess: $$sanitized_props.class
    });
    elClass = ClassMerge({
      name: componentName,
      componentClass,
      staticClassess: inputClass
    });
    labelClass = ClassMerge({ name: `${componentName}-label` });
    {
      if (pattern && node) {
        if (node.validity.valid || node.validity.valueMissing) {
          show_hint_pattern = true;
        } else {
          show_hint_pattern = false;
        }
      }
    }
    hintClass = ClassMerge({
      name: `${componentName}-hint`,
      componentClass: {
        "state-valid": state == "valid",
        "state-invalid": state == "invalid",
        "pattern-invalid": pattern && !show_hint_pattern
      }
    });
    list = suggestions && suggestions.length ? `list-${Math.floor(Math.random() * 1e5)}` : "";
    $$renderer2.push(`<label${attr_class(clsx(wrapperClass))}><!--[-->`);
    slot($$renderer2, $$props, "label", {}, () => {
      if (label) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span${attr_class(clsx(labelClass))}>${escape_html(label)}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    });
    $$renderer2.push(`<!--]--> `);
    El($$renderer2, {
      class: inputWrapper,
      children: ($$renderer3) => {
        El($$renderer3, {
          class: startWrapper,
          children: ($$renderer4) => {
            $$renderer4.push(`<!--[-->`);
            slot($$renderer4, $$props, "start", {}, null);
            $$renderer4.push(`<!--]-->`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> <input${attributes(
          {
            ...$$restProps,
            readonly,
            type,
            disabled,
            value,
            placeholder,
            class: clsx(elClass),
            pattern,
            list
          },
          void 0,
          void 0,
          void 0,
          4
        )}/> `);
        if (list && suggestions) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<datalist${attr("id", list)}><!--[-->`);
          const each_array = ensure_array_like(suggestions);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let _item = each_array[$$index];
            $$renderer3.option({ value: _item }, ($$renderer4) => {
            });
          }
          $$renderer3.push(`<!--]--></datalist>`);
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--> `);
        El($$renderer3, {
          class: endWrapper,
          children: ($$renderer4) => {
            $$renderer4.push(`<!--[-->`);
            slot($$renderer4, $$props, "end", {}, null);
            $$renderer4.push(`<!--]-->`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!---->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    if (hint) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span${attr_class(clsx(hintClass))}>${html(hint)}</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></label>`);
    bind_props($$props, {
      label,
      placeholder,
      value,
      type,
      disabled,
      readonly,
      size,
      color,
      hint,
      state,
      ghost,
      inputClass,
      node,
      suggestions,
      pattern
    });
  });
}
const ctx$1 = {};
function getCheckboxGroupContext() {
  return getContext(ctx$1);
}
function Checkbox($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let disabledCombined, componentClass, wrapperClass, elClass;
    let componentName = "checkbox";
    let checked = fallback($$props["checked"], false);
    let label = fallback($$props["label"], void 0);
    let value = fallback($$props["value"], "");
    let disabled = fallback($$props["disabled"], false);
    let indeterminate = fallback($$props["indeterminate"], false);
    let size = fallback($$props["size"], void 0);
    let color = fallback($$props["color"], void 0);
    const ctx2 = getCheckboxGroupContext();
    ctx2?.selected ?? writable();
    const disabledStore = ctx2?.disabled;
    disabledCombined = disabledStore ? disabled || store_get($$store_subs ??= {}, "$disabledStore", disabledStore) : disabled;
    componentClass = {
      xs: size == "xs",
      sm: size == "sm",
      md: size == "md",
      lg: size == "lg",
      xl: size == "xl",
      disabled,
      primary: color == "primary",
      secondary: color == "secondary",
      accent: color == "accent",
      success: color == "success",
      info: color == "info",
      error: color == "error",
      warning: color == "warning",
      neutral: color == "neutral",
      diabled: disabledCombined
    };
    wrapperClass = ClassMerge({
      name: `${componentName}-wrapper`,
      staticClassess: $$sanitized_props.class
    });
    elClass = ClassMerge({ name: componentName, componentClass });
    $$renderer2.push(`<label${attr_class(clsx(wrapperClass))}><input type="checkbox"${attr("disabled", disabledCombined, true)}${attr("value", value)}${attr_class(clsx(elClass))}${attr("checked", checked, true)}/> <!--[-->`);
    slot($$renderer2, $$props, "label", {}, () => {
      $$renderer2.push(`${escape_html(label)}`);
    });
    $$renderer2.push(`<!--]--></label>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { checked, label, value, disabled, indeterminate, size, color });
  });
}
const ctx = {};
function getRadioGroupContext() {
  return getContext(ctx);
}
function setRadioGroupContext(value) {
  return setContext(ctx, value);
}
function RadioGroup($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  $$renderer.component(($$renderer2) => {
    let elClass;
    let componentName = "radio-group";
    let value = fallback($$props["value"], void 0);
    let inline = fallback($$props["inline"], false);
    let column = fallback($$props["column"], false);
    let disabled = fallback($$props["disabled"], false);
    let join = fallback($$props["join"], false);
    if (!inline && !column) inline = true;
    const selected = writable(null);
    const disabledStore = writable(disabled);
    setRadioGroupContext({ join, selected, disabled: disabledStore });
    selected.subscribe((val) => {
      if (val && val != value) {
        value = val;
      }
    });
    function onValueChange() {
      selected.set(value);
    }
    onValueChange();
    disabledStore.set(disabled);
    elClass = ClassMerge({
      name: componentName,
      componentClass: { join, inline, column, disabled },
      staticClassess: $$sanitized_props.class
    });
    $$renderer2.push(`<div${attr_class(clsx(elClass))}><!--[-->`);
    slot($$renderer2, $$props, "default", {}, null);
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { value, inline, column, disabled, join });
  });
}
function Radio($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let disabledCombined, componentClass, wrapperClass, elClass;
    let componentName = "radio";
    let label = fallback($$props["label"], void 0);
    let value = fallback($$props["value"], "");
    let disabled = fallback($$props["disabled"], false);
    let size = fallback($$props["size"], void 0);
    let color = fallback($$props["color"], void 0);
    let button = fallback($$props["button"], false);
    const ctx2 = getRadioGroupContext();
    const disabledStore = ctx2?.disabled;
    const selected = ctx2?.selected ?? writable();
    disabledCombined = disabledStore ? disabled || store_get($$store_subs ??= {}, "$disabledStore", disabledStore) : disabled;
    componentClass = {
      xs: size == "xs",
      sm: size == "sm",
      md: size == "md",
      lg: size == "lg",
      xl: size == "xl",
      disabled: disabledCombined,
      primary: color == "primary",
      secondary: color == "secondary",
      accent: color == "accent",
      success: color == "success",
      info: color == "info",
      error: color == "error",
      warning: color == "warning",
      neutral: color == "neutral",
      button,
      join: ctx2?.join
    };
    wrapperClass = ClassMerge({
      name: `${componentName}-wrapper`,
      staticClassess: $$sanitized_props.class
    });
    elClass = ClassMerge({ name: componentName, componentClass });
    if (button) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<input${attr("aria-label", label)} type="radio"${attr("checked", store_get($$store_subs ??= {}, "$selected", selected) == value, true)}${attr("disabled", disabledCombined, true)}${attr("value", value)}${attr_class(clsx(elClass))}/>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<label${attr_class(clsx(wrapperClass))}><input type="radio"${attr("checked", store_get($$store_subs ??= {}, "$selected", selected) == value, true)}${attr("disabled", disabledCombined, true)}${attr("value", value)}${attr_class(clsx(elClass))}/> <!--[-->`);
      slot($$renderer2, $$props, "label", {}, () => {
        $$renderer2.push(`${escape_html(label)}`);
      });
      $$renderer2.push(`<!--]--></label>`);
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { label, value, disabled, size, color, button });
  });
}
function HomePage($$renderer) {
  let animateValue, demo_1_ClassNameHandler, demo_1_StyleHandler, demo_1_ElementTextHandler;
  let toggleValueForCodeCompare = false;
  let scrollY;
  function scaleValue(value, from, to) {
    let scale = (to[1] - to[0]) / (from[1] - from[0]);
    let capped = Math.min(from[1], Math.max(from[0], value)) - from[0];
    return capped * scale + to[0];
  }
  let section = [];
  let demo_1_ClassNames = [
    "bg-indigo-600 px-4 py-3 text-center text-sm font-semibold inline-block text-white cursor-pointer uppercase transition duration-200 ease-in-out rounded-md hover:bg-indigo-700 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2 active:scale-95",
    "btn btn-primary"
  ];
  scrollY = scrollY;
  animateValue = function(targetElement, scrollPercentage, animateRange) {
    if (targetElement) {
      return scaleValue(((scrollY || 0) - targetElement.offsetTop) / targetElement.clientHeight * 100, scrollPercentage, animateRange);
    }
    return 0;
  };
  demo_1_ClassNameHandler = () => {
    if (section["hero"] && scrollY / (section["hero"].offsetTop + section["hero"].clientHeight) * 100 > 25 && scrollY / (section["hero"].offsetTop + section["hero"].clientHeight) * 100 < 65) {
      return demo_1_ClassNames[0].slice(0, Math.trunc(animateValue(section["hero"], [25, 65], [0, demo_1_ClassNames[0].length])));
    } else if (section["hero"] && scrollY / (section["hero"].offsetTop + section["hero"].clientHeight) * 100 > 65 && scrollY / (section["hero"].offsetTop + section["hero"].clientHeight) * 100 < 80) {
      return demo_1_ClassNames[0].slice(0, Math.trunc(animateValue(section["hero"], [75, 80], [demo_1_ClassNames[0].length, 0])));
    } else if (section["hero"] && scrollY / (section["hero"].offsetTop + section["hero"].clientHeight) * 100 > 80) {
      return demo_1_ClassNames[1].slice(0, Math.trunc(animateValue(section["hero"], [80, 82], [0, demo_1_ClassNames[1].length])));
    }
    return "";
  };
  demo_1_StyleHandler = () => {
    if (section["hero"] && scrollY / (section["hero"].offsetTop + section["hero"].clientHeight) * 100 > 80) {
      return "text-teal-700";
    }
    return "text-rose-600";
  };
  demo_1_ElementTextHandler = () => {
    if (section["hero"] && scrollY / (section["hero"].offsetTop + section["hero"].clientHeight) * 100 > 80) {
      return "Uikit Button";
    }
    return "Tailwind Button";
  };
  let $$settled = true;
  let $$inner_renderer;
  function $$render_inner($$renderer2) {
    $$renderer2.push(`<div><div class="flex min-h-[550vh] max-w-screen flex-col items-center justify-start xl:flex-row xl:items-start xl:justify-between"><div class="shrink xl:w-1/2"><div${attr_class("flex min-h-[calc(100vh-4rem)] items-center justify-center px-2 py-10 text-center xl:justify-start xl:pe-0 xl:ps-10 xl:text-start", void 0, {
      "invisible": section["hero"] && scrollY > section["hero"].clientHeight
    })}><div><h1 class="font-title text-center text-[clamp(2rem,6vw,4.2rem)] font-black leading-[1.1] [word-break:auto-phrase] xl:w-[115%] xl:text-start [:root[dir=rtl]_&amp;]:leading-[1.35]"><span class="[&amp;::selection]:text-base-content brightness-150 contrast-150 [&amp;::selection]:bg-blue-700/20">The most popular</span> <br/> <span class="inline-grid"><span class="pointer-events-none col-start-1 row-start-1 bg-[linear-gradient(90deg,var(--color-error)_0%,var(--color-secondary)_9%,var(--color-secondary)_42%,var(--color-primary)_47%,var(--color-accent)_100%)] bg-clip-text blur-xl [-webkit-text-fill-color:transparent] [transform:translate3d(0,0,0)] before:content-[attr(data-text)] [@supports(color:oklch(0%_0_0))]:bg-[linear-gradient(90deg,oklch(var(--s))_4%,color-mix(in_oklch,oklch(var(--s)),oklch(var(--er)))_22%,oklch(var(--p))_45%,color-mix(in_oklch,oklch(var(--p)),oklch(var(--a)))_67%,oklch(var(--a))_100.2%)]" aria-hidden="true" data-text="component library"></span> <span class="[&amp;::selection]:text-base-content relative col-start-1 row-start-1 bg-[linear-gradient(90deg,var(--color-error)_0%,var(--color-secondary)_9%,var(--color-secondary)_42%,var(--color-primary)_47%,var(--color-accent)_100%)] bg-clip-text [-webkit-text-fill-color:transparent] [&amp;::selection]:bg-blue-700/20 [@supports(color:oklch(0%_0_0))]:bg-[linear-gradient(90deg,oklch(var(--s))_4%,color-mix(in_oklch,oklch(var(--s)),oklch(var(--er)))_22%,oklch(var(--p))_45%,color-mix(in_oklch,oklch(var(--p)),oklch(var(--a)))_67%,oklch(var(--a))_100.2%)]">component library</span></span> <br/> <span class="[&amp;::selection]:text-base-content brightness-150 contrast-150 [&amp;::selection]:bg-blue-700/20">for Tailwind CSS</span></h1> <div class="h-4"></div> <p class="text-base-content/70 font-title py-4 font-light md:text-lg xl:text-2xl svelte-ovge82">${html("Uikit adds component class names to Tailwind&nbsp;CSS<br /> so you can make beautiful websites <span class='border-base-content/20 border-b-2'>faster than ever.</span>")}</p> <div class="h-10"></div> <div><div class="inline-flex w-full flex-col items-stretch justify-center gap-2 px-4 md:flex-row xl:justify-start xl:px-0">`);
    Button($$renderer2, {
      href: "/docs/component/button",
      size: "lg",
      class: "rounded-full flex-1",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->See Components`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    Button($$renderer2, {
      size: "lg",
      class: "group rounded-full flex-1",
      color: "natural",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->How to use? <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="hidden h-6 w-6 transition-transform duration-300 group-hover:translate-x-1 rtl:rotate-180 rtl:group-hover:-translate-x-1 md:inline-block"><path stroke-linecap="round" stroke-linejoin="round" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3"></path></svg>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div></div></div> <div class="xl:h-[calc(20vh)]"></div> <div><div class="max-w-screen px-2 py-10 lg:px-10 xl:max-w-[50vw]"><div class="font-title text-center xl:text-start"><h2 class="text-[clamp(2.5rem,6vw,4.5rem)] font-bold leading-none">${html("don't re-invent <br/>the wheel <br/>every time")} <img loading="lazy" width="72" height="72" alt="yawing face emoji" src="/yawning-face@80.webp"${attr("srcset", `/yawning-face@80.webp`)} class="pointer-events-none inline-block h-[1em] w-[1em] align-bottom"/></h2> <p class="text-base-content/70 font-title py-4 font-light md:text-2xl svelte-ovge82">${html("In a Tailwind CSS project, you need to write utility class names for every element. Thousands of class names just to style the most basic elements.")}</p> <div class="h-40"></div> <div class="relative h-[300vh]"><div class="sticky top-[16vh] xl:top-[30vh]"><h2 class="text-[clamp(2.5rem,6vw,4.5rem)] font-light leading-none">${html("instead of writing<br /> <span class='text-error'><span class='font-black'>100</span> class names</span>")}</h2> <div class="h-6"></div> <p class="text-base-content/70 font-title py-4 font-light md:text-2xl svelte-ovge82">${html("For every element, every page, every project,<br/>again and again")}…</p> <div class="h-24"></div></div></div> <div class="relative h-screen"><div class="sticky top-[16vh] xl:top-[30vh]"><h2 class="text-[clamp(2.5rem,6vw,4.5rem)] font-light leading-none">${html("use <span class='text-success'><span class='font-black'>semantic</span> <br />Components</span>")} <img loading="lazy" width="72" height="72" alt="sunglasses emoji" src="/smiling-face-with-sunglasses@80.webp"${attr("srcset", `/smiling-face-with-sunglasses@80.webp`)} class="pointer-events-none inline-block h-[1em] w-[1em] align-bottom"/></h2> <div class="h-6"></div> <p class="text-base-content/70 font-title py-4 font-light md:text-2xl svelte-ovge82">It's descriptive, faster, cleaner and easier to maintain.</p> <div class="h-20"></div></div></div></div></div></div></div> <div class="invisible sticky bottom-4 flex w-[calc(100%-2rem)] shrink duration-700 xl:visible xl:-end-32 xl:bottom-auto xl:top-16 xl:w-auto xl:transform-none! xl:overflow-x-hidden xl:overflow-y-clip xl:bg-transparent xl:pb-16 xl:pt-16"${attr_style(`${section["hero"] && scrollY > section["hero"].clientHeight * 0.2 ? "visibility: visible;" : ""}transform:translateY(${animateValue(section["hero"], [17, 25], [120, 0])}%)`)}><div${attr_class("mockup mockup-window bg-base-200/90 xl:bg-base-200 mx-auto origin-top overflow-visible pb-4 backdrop-blur will-change-auto [--rtl-reverse:1] [transform:rotateX(20deg)rotateZ(-20deg)skewY(8deg)scale(1)] rtl:[--rtl-reverse:-1] rtl:[transform:rotateX(20deg)rotateZ(20deg)skewY(-8deg)scale(1)] max-[1279px]:[transform:translate3d(0,0,0)]! xl:-end-20 xl:-me-10 xl:h-128 xl:w-200 xl:rounded-e-none xl:pe-4 xl:shadow-[-0.05rem_0.1rem_0rem_#00000014] xl:backdrop-blur-0 svelte-ovge82", void 0, {
      "invisible": section["hero"] && scrollY > section["hero"].clientHeight
    })}${attr_style(section["hero"] && `transform: rotateX(${animateValue(section["hero"], [7, 17], [20, 0])}deg)rotateZ(calc(${animateValue(section["hero"], [7, 17], [-20, 0])}deg * var(--rtl-reverse)))skewY(calc(${animateValue(section["hero"], [7, 17], [8, 0])}deg * var(--rtl-reverse)))`)}><div class="grid"><div${attr_style(`opacity:${animateValue(section["hero"], [15, 17], [1, 0])}`)}${attr_class("z-1 col-start-1 row-start-1 grid overflow-y-hidden overflow-x-scroll [scrollbar-width:none] xl:visible xl:overflow-x-visible xl:overflow-y-visible [&amp;::-webkit-scrollbar]:hidden", void 0, {
      "invisible": section["hero"] && scrollY < section["hero"].clientHeight
    })}><div class="col-start-1 row-start-1 mx-6 flex items-end gap-6 xl:mx-0 xl:items-start xl:gap-0"><div class="flex gap-6 xl:w-60 xl:flex-col xl:gap-0"><div class="relative z-1 w-80 will-change-auto motion-reduce:transform-none! max-[1279px]:[transform:translate3d(0,0,0)]! xl:-start-6 xl:w-auto xl:filter-[drop-shadow(-1rem_3rem_1rem_#00000012)]"${attr_style(`filter: drop-shadow(calc(-1rem * var(--rtl-reverse)) 3rem 1rem #00000012);transform:translate(calc(${animateValue(section["hero"], [8, 15], [0, 250])}px * var(--rtl-reverse)),${animateValue(section["hero"], [2, 9], [0, -800])}px)`)}>`);
    Tabs($$renderer2, {
      variant: "lift",
      selected: "Features",
      children: ($$renderer3) => {
        TabItem($$renderer3, {
          value: "Features",
          title: "Features",
          children: ($$renderer4) => {
            $$renderer4.push(`<div class="bg-base-100 rounded-b-box h-60 shrink-0 rounded-se-box w-64"><div class="flex flex-col items-stretch p-6 gap-2"><div class="form-control">`);
            Switch($$renderer4, {
              value: true,
              color: "primary",
              size: "sm",
              $$slots: {
                label: ($$renderer5) => {
                  $$renderer5.push(`<span slot="label" class="label-text text-xs">Faster development</span>`);
                }
              }
            });
            $$renderer4.push(`<!----></div> <div class="form-control">`);
            Switch($$renderer4, {
              value: true,
              color: "secondary",
              size: "sm",
              $$slots: {
                label: ($$renderer5) => {
                  $$renderer5.push(`<span slot="label" class="label-text text-xs">Cleaner HTML</span>`);
                }
              }
            });
            $$renderer4.push(`<!----></div> <div class="form-control">`);
            Switch($$renderer4, {
              value: true,
              color: "accent",
              size: "sm",
              $$slots: {
                label: ($$renderer5) => {
                  $$renderer5.push(`<span slot="label" class="label-text text-xs">Customizable</span>`);
                }
              }
            });
            $$renderer4.push(`<!----></div> <div class="form-control">`);
            Switch($$renderer4, {
              value: true,
              color: "success",
              size: "sm",
              $$slots: {
                label: ($$renderer5) => {
                  $$renderer5.push(`<span slot="label" class="label-text text-xs">Themeable</span>`);
                }
              }
            });
            $$renderer4.push(`<!----></div> <div class="form-control">`);
            Switch($$renderer4, {
              color: "error",
              value: false,
              size: "sm",
              $$slots: {
                label: ($$renderer5) => {
                  $$renderer5.push(`<span slot="label" class="label-text text-xs">More Code</span>`);
                }
              }
            });
            $$renderer4.push(`<!----></div></div></div>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> `);
        TabItem($$renderer3, {
          value: "Links",
          title: "Links",
          children: ($$renderer4) => {
            $$renderer4.push(`<div class="bg-base-100 rounded-b-box h-60 shrink-0 p-2 w-64 rounded-se-box rounded-ss-box"><div class="menu-title svelte-ovge82">Dashboard</div> <div class="flex flex-col gap-1">`);
            Button($$renderer4, {
              size: "sm",
              class: "justify-start",
              variant: "ghost",
              children: ($$renderer5) => {
                $$renderer5.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5"><path d="M15.5 2A1.5 1.5 0 0014 3.5v13a1.5 1.5 0 001.5 1.5h1a1.5 1.5 0 001.5-1.5v-13A1.5 1.5 0 0016.5 2h-1zM9.5 6A1.5 1.5 0 008 7.5v9A1.5 1.5 0 009.5 18h1a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0010.5 6h-1zM3.5 10A1.5 1.5 0 002 11.5v5A1.5 1.5 0 003.5 18h1A1.5 1.5 0 006 16.5v-5A1.5 1.5 0 004.5 10h-1z"></path></svg> Dashboard`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              size: "sm",
              class: "justify-start",
              variant: "ghost",
              children: ($$renderer5) => {
                $$renderer5.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5"><path d="M9.653 16.915l-.005-.003-.019-.01a20.759 20.759 0 01-1.162-.682 22.045 22.045 0 01-2.582-1.9C4.045 12.733 2 10.352 2 7.5a4.5 4.5 0 018-2.828A4.5 4.5 0 0118 7.5c0 2.852-2.044 5.233-3.885 6.82a22.049 22.049 0 01-3.744 2.582l-.019.01-.005.003h-.002a.739.739 0 01-.69.001l-.002-.001z"></path></svg> Notifications`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              size: "sm",
              class: "justify-start",
              variant: "ghost",
              children: ($$renderer5) => {
                $$renderer5.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5"><path fill-rule="evenodd" d="M2 10c0-3.967 3.69-7 8-7 4.31 0 8 3.033 8 7s-3.69 7-8 7a9.165 9.165 0 01-1.504-.123 5.976 5.976 0 01-3.935 1.107.75.75 0 01-.584-1.143 3.478 3.478 0 00.522-1.756C2.979 13.825 2 12.025 2 10z" clip-rule="evenodd"></path></svg> Messages`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              size: "sm",
              class: "justify-start",
              variant: "ghost",
              children: ($$renderer5) => {
                $$renderer5.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5"><path d="M10 8a3 3 0 100-6 3 3 0 000 6zM3.465 14.493a1.23 1.23 0 00.41 1.412A9.957 9.957 0 0010 18c2.31 0 4.438-.784 6.131-2.1.43-.333.604-.903.408-1.41a7.002 7.002 0 00-13.074.003z"></path></svg> People`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              size: "sm",
              class: "justify-start",
              variant: "ghost",
              children: ($$renderer5) => {
                $$renderer5.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5"><path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z" clip-rule="evenodd"></path></svg> Products`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----></div></div>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> `);
        TabItem($$renderer3, {
          value: "Message",
          title: "Message",
          children: ($$renderer4) => {
            $$renderer4.push(`<div class="bg-base-100 rounded-b-box h-60 shrink-0 p-2 w-64 rounded-ss-box"><div class="flex h-full flex-col px-4 py-4"><div class="grow"><div class="chat chat-start svelte-ovge82"><div class="chat-image avatar svelte-ovge82">`);
            Avatar($$renderer4, {
              shape: "circle",
              size: "xs",
              children: ($$renderer5) => {
                $$renderer5.push(`<img loading="lazy" src="/tailwind-css-component-profile-1@94w.jpg" alt="tailwind css avatar component"/>`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----></div> <div class="chat-bubble text-xs in-[.chat]:before:start-[-0.73rem] svelte-ovge82">Use Tailwind CSS but write fewer class names.</div></div></div> <div class="daisy-join w-full">`);
            TextField($$renderer4, {
              placeholder: "Message",
              size: "sm",
              class: "daisy-join-item",
              inputClass: "daisy-join-item"
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              class: "daisy-join-item",
              size: "sm",
              color: "natural",
              children: ($$renderer5) => {
                $$renderer5.push(`<svg fill="currentColor" class="h-4 w-4" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M19,6a1,1,0,0,0-1,1v4a1,1,0,0,1-1,1H7.41l1.3-1.29A1,1,0,0,0,7.29,9.29l-3,3a1,1,0,0,0-.21.33,1,1,0,0,0,0,.76,1,1,0,0,0,.21.33l3,3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42L7.41,14H17a3,3,0,0,0,3-3V7A1,1,0,0,0,19,6Z"></path></svg>`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----></div></div></div>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!---->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div> <div class="flex w-60 flex-col justify-end gap-4 xl:w-auto xl:justify-normal xl:p-6"><div class="flex gap-3 items-center p-4 rounded-btn border-base-300 border will-change-auto motion-reduce:transform-none! motion-reduce:shadow-none! max-[1279px]:[transform:translate3d(0,0,0)]!"${attr_style(`box-shadow:calc(${animateValue(section["hero"], [5, 5.5], [0, -1])}rem * var(--rtl-reverse)) ${animateValue(section["hero"], [5, 5.5], [0, 3])}rem ${animateValue(section["hero"], [5, 5.5], [0, 1])}rem #00000012;transform:translate(calc(${animateValue(section["hero"], [5, 15], [0, 250])}px * var(--rtl-reverse)),${animateValue(section["hero"], [5, 15], [0, -800])}px)`)}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5 shrink-0"><path fill-rule="evenodd" d="M9.661 2.237a.531.531 0 01.678 0 11.947 11.947 0 007.078 2.749.5.5 0 01.479.425c.069.52.104 1.05.104 1.59 0 5.162-3.26 9.563-7.834 11.256a.48.48 0 01-.332 0C5.26 16.564 2 12.163 2 7c0-.538.035-1.069.104-1.589a.5.5 0 01.48-.425 11.947 11.947 0 007.077-2.75zm4.196 5.954a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clip-rule="evenodd"></path></svg> <span class="text-xs">${html("Pure CSS. <br />No JS dependency")}</span></div> <div class="flex gap-3 items-center p-4 rounded-btn border-base-300 border will-change-auto motion-reduce:transform-none! motion-reduce:shadow-none! max-[1279px]:[transform:translate3d(0,0,0)]!"${attr_style(`box-shadow:calc(${animateValue(section["hero"], [6, 6.5], [0, -1])}rem * var(--rtl-reverse)) ${animateValue(section["hero"], [6, 6.5], [0, 3])}rem ${animateValue(section["hero"], [6, 6.5], [0, 1])}rem #00000012;transform:translate(calc(${animateValue(section["hero"], [6, 16], [0, 250])}px * var(--rtl-reverse)),${animateValue(section["hero"], [6, 16], [0, -800])}px)`)}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-5 w-5 shrink-0"><path d="M15.98 1.804a1 1 0 00-1.96 0l-.24 1.192a1 1 0 01-.784.785l-1.192.238a1 1 0 000 1.962l1.192.238a1 1 0 01.785.785l.238 1.192a1 1 0 001.962 0l.238-1.192a1 1 0 01.785-.785l1.192-.238a1 1 0 000-1.962l-1.192-.238a1 1 0 01-.785-.785l-.238-1.192zM6.949 5.684a1 1 0 00-1.898 0l-.683 2.051a1 1 0 01-.633.633l-2.051.683a1 1 0 000 1.898l2.051.684a1 1 0 01.633.632l.683 2.051a1 1 0 001.898 0l.683-2.051a1 1 0 01.633-.633l2.051-.683a1 1 0 000-1.898l-2.051-.683a1 1 0 01-.633-.633L6.95 5.684zM13.949 13.684a1 1 0 00-1.898 0l-.184.551a1 1 0 01-.632.633l-.551.183a1 1 0 000 1.898l.551.183a1 1 0 01.633.633l.183.551a1 1 0 001.898 0l.184-.551a1 1 0 01.632-.633l.551-.183a1 1 0 000-1.898l-.551-.184a1 1 0 01-.633-.632l-.183-.551z"></path></svg> <span class="text-xs">Works on all frameworks</span></div></div></div> <div class="flex shrink-0 gap-6 pe-4 xl:flex-col xl:pe-0"><div class="flex flex-col rounded-2xl bg-base-100 shadow-xs will-change-auto motion-reduce:transform-none! motion-reduce:shadow-xs! max-[1279px]:[transform:translate3d(0,0,0)]!"${attr_style(`--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05), calc(${animateValue(section["hero"], [0, 0.5], [0, -1])}rem * var(--rtl-reverse)) ${animateValue(section["hero"], [0, 0.5], [0, 3])}rem ${animateValue(section["hero"], [0, 0.5], [0, 1])}rem #00000012;transform:translate(calc(${animateValue(section["hero"], [0, 8], [0, 250])}px * var(--rtl-reverse)),${animateValue(section["hero"], [0, 8], [0, -800])}px)`)}><div class="p-8"><h2 class="font-semibold mb-4 text-sm">Design system</h2> <div class="grid grid-cols-4 items-end gap-4 mb-4"><div class="flex flex-col items-center text-[.6rem] text-base-content/70 gap-1">`);
    Checkbox($$renderer2, { color: "primary", size: "xs" });
    $$renderer2.push(`<!----> checkbox-xs</div> <div class="flex flex-col items-center text-[.6rem] text-base-content/70 gap-1">`);
    Checkbox($$renderer2, { color: "primary", size: "sm" });
    $$renderer2.push(`<!----> checkbox-sm</div> <div class="flex flex-col items-center text-[.6rem] text-base-content/70 gap-1">`);
    Checkbox($$renderer2, { color: "primary", size: "md" });
    $$renderer2.push(`<!----> checkbox-md</div> <div class="flex flex-col items-center text-[.6rem] text-base-content/70 gap-1">`);
    Checkbox($$renderer2, { color: "primary", size: "lg" });
    $$renderer2.push(`<!----> checkbox-lg</div></div> `);
    RadioGroup($$renderer2, {
      class: "grid! grid-cols-4 items-end gap-4 w-full",
      children: ($$renderer3) => {
        $$renderer3.push(`<div class="flex flex-col items-center gap-1">`);
        Radio($$renderer3, { color: "secondary", value: "xs", size: "xs" });
        $$renderer3.push(`<!----> <span class="text-base-content/70 text-[.6rem]">radio-xs</span></div> <div class="flex flex-col items-center gap-1">`);
        Radio($$renderer3, { color: "secondary", value: "sm", size: "sm" });
        $$renderer3.push(`<!----> <span class="text-base-content/70 text-[.6rem]">radio-sm</span></div> <div class="flex flex-col items-center gap-1">`);
        Radio($$renderer3, { color: "secondary", value: "md", size: "md" });
        $$renderer3.push(`<!----> <span class="text-base-content/70 text-[.6rem]">radio-md</span></div> <div class="flex flex-col items-center gap-1">`);
        Radio($$renderer3, { color: "secondary", value: "lg", size: "lg" });
        $$renderer3.push(`<!----> <span class="text-base-content/70 text-[.6rem]">radio-lg</span></div>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div> <div class="flex flex-col rounded-2xl bg-base-100 shadow-xs will-change-auto motion-reduce:transform-none! motion-reduce:shadow-xs! max-[1279px]:[transform:translate3d(0,0,0)]!"${attr_style(`--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05), calc(${animateValue(section["hero"], [4, 4.5], [0, -1])}rem * var(--rtl-reverse)) ${animateValue(section["hero"], [4, 4.5], [0, 3])}rem ${animateValue(section["hero"], [4, 4.5], [0, 1])}rem #00000012;transform:translate(calc(${animateValue(section["hero"], [4, 10], [0, 250])}px * var(--rtl-reverse)),${animateValue(section["hero"], [4, 10], [0, -800])}px)`)}><div class="p-8"><h2 class="font-semibold mb-4 text-sm">Semantic colors</h2> <div class="grid grid-cols-4 gap-4"><div class="flex flex-col items-center gap-1"><div class="bg-primary rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">primary</div></div> <div class="flex flex-col items-center gap-1"><div class="bg-secondary rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">secondary</div></div> <div class="flex flex-col items-center gap-1"><div class="bg-accent rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">accent</div></div> <div class="flex flex-col items-center gap-1"><div class="bg-neutral rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">neutral</div></div> <div class="flex flex-col items-center gap-1"><div class="bg-info rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">info</div></div> <div class="flex flex-col items-center gap-1"><div class="bg-success rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">success</div></div> <div class="flex flex-col items-center gap-1"><div class="bg-warning rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">warning</div></div> <div class="flex flex-col items-center gap-1"><div class="bg-error rounded-btn aspect-square w-10"></div> <div class="text-base-content/70 text-[.6rem]">error</div></div></div></div></div></div></div></div> <div dir="ltr" class="col-start-1 row-start-1 w-11/12 pb-3 pe-10 ps-10 opacity-0 rtl:ps-0 sm:pb-10 lg:pe-4 rtl:lg:ps-20 xl:ps-20 xl:pt-10"${attr_style(`opacity:${animateValue(section["hero"], [16, 17], [0, 1])};z-index:${animateValue(section["hero"], [20, 22], [0, 1])}`)}><pre class="max-w-lg text-xs sm:text-base">
						<code class="whitespace-pre-line">
<span class="text-base-content/40 italic">// Styling a simple button</span>
`);
    if (demo_1_ElementTextHandler() == "Uikit Button") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`
									&lt;Button color="primary" >
	${escape_html(demo_1_ElementTextHandler())}
	&lt;/Button>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`&lt;button class="<span${attr_class(`${demo_1_StyleHandler()}`, "svelte-ovge82")}>${escape_html(demo_1_ClassNameHandler())}</span>">
	${escape_html(demo_1_ElementTextHandler())}
	&lt;/button>`);
    }
    $$renderer2.push(`<!--]-->
		</code>
					</pre> <div><div class="text-base-content/40 py-6 font-mono text-xs italic sm:text-base">// Result:</div> `);
    if (demo_1_ElementTextHandler() == "Uikit Button") {
      $$renderer2.push("<!--[-->");
      Button($$renderer2, {
        color: "primary",
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->${escape_html(demo_1_ElementTextHandler())}`);
        },
        $$slots: { default: true }
      });
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<button${attr_class(`${demo_1_ClassNameHandler()}`, "svelte-ovge82")}>${escape_html(demo_1_ElementTextHandler())}</button>`);
    }
    $$renderer2.push(`<!--]--></div></div></div></div></div></div> <div class="w-full px-2 py-10 md:py-20 lg:py-40 lg:px-10"><div class="text-center"><h2 class="font-title relative z-2 mx-auto text-[clamp(2rem,6vw,4.5rem)] font-black leading-none will-change-auto [transform:translate3d(0,0,0)] motion-reduce:tracking-normal! max-[1279px]:tracking-normal!"${attr_style(`letter-spacing:${animateValue(section["nextlevel"], [-100, 20], [1, 0])}rem`)}>Take Tailwind CSS <br/> <span class="bg-[linear-gradient(90deg,var(--color-error)_0%,var(--color-secondary)_9%,var(--color-secondary)_42%,var(--color-primary)_47%,var(--color-accent)_100%)] bg-clip-text will-change-auto [-webkit-text-fill-color:transparent] [transform:translate3d(0,0,0)] motion-reduce:tracking-normal! max-[1279px]:tracking-normal! [@supports(color:oklch(0%_0_0))]:bg-[linear-gradient(90deg,oklch(var(--s))_4%,color-mix(in_oklch,oklch(var(--s)),oklch(var(--er)))_22%,oklch(var(--p))_45%,color-mix(in_oklch,oklch(var(--p)),oklch(var(--a)))_67%,oklch(var(--a))_100.2%)]"${attr_style(`letter-spacing:${animateValue(section["nextlevel"], [-100, 20], [0, 1])}rem`)}>to the next level</span></h2> <p class="text-base-content/70 font-title py-4 font-light md:text-2xl svelte-ovge82">${html("Uikit adds components to Tailwind CSS<br />for Svelete library.<br />components  like")} <a target="_blank" href="/docs/component/button/" class="text-primary">Button</a> , <a target="_blank" href="/docs/component/tabs/" class="text-primary">Tabs</a> , <a target="_blank" href="/docs/component/switch/" class="text-primary">Switch</a> and many more.</p> <div class="h-6"></div> <p class="text-success font-title font-light md:text-2xl svelte-ovge82">${html("This allows us to focus on important things<br />instead of styling basic elements for every project.")}</p> <div class="h-12"></div> <div class="flex w-full justify-center">`);
    Button($$renderer2, {
      href: "/docs/component/button",
      color: "primary",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->all-components-btn`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----></div></div></div> <div><div><div class="relative overflow-hidden"><div class="w-full px-2 py-10 md:py-20 lg:py-40 lg:px-10"><div class="text-center"><h2 class="font-title relative z-2 mx-auto text-[clamp(2.5rem,6vw,4.5rem)] font-black leading-none"><span class="motion-reduce:opacity-100!"${attr_style(`opacity:${section["uglyhtml"] && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 > -100 && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 < -30 ? 0.1 : 1}`)}>No</span> <span class="motion-reduce:opacity-100!"${attr_style(`opacity:${section["uglyhtml"] && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 > -100 && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 < -25 ? 0.1 : 1}`)}>more</span> <span class="motion-reduce:opacity-100!"${attr_style(`opacity:${section["uglyhtml"] && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 > -100 && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 < -20 ? 0.1 : 1}`)}>ugly</span> <span class="motion-reduce:opacity-100!"${attr_style(`opacity:${section["uglyhtml"] && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 > -100 && (scrollY - section["uglyhtml"].offsetTop) / section["uglyhtml"].clientHeight * 100 < -15 ? 0.1 : 1}`)}>HTML</span></h2> <p class="text-base-content/70 font-title relative z-2 py-4 font-light md:text-3xl svelte-ovge82">${html("Write fewer class names<br />Use component class names<br />modify them using Tailwind CSS utilities.")}</p> <div class="h-4"></div> <div class="mx-auto w-72 text-start"><span class="text-base-content/70 inline-block -translate-y-2 -rotate-12">Click</span> <svg class="text-base-content/20 inline-block h-8 w-20 rtl:[transform:rotateY(180deg)]" viewBox="0 0 45 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1.50244C23.4 -1.69756 38.3333 11.1691 43 18.0024M43 18.0024L38 17.0024M43 18.0024V13.0024" stroke="currentColor"></path></svg></div> <div class="flex justify-center pb-10 pt-4"><div class="flex items-center gap-3">Tailwind only `);
    Switch($$renderer2, {
      size: "lg",
      color: "primary",
      get value() {
        return toggleValueForCodeCompare;
      },
      set value($$value) {
        toggleValueForCodeCompare = $$value;
        $$settled = false;
      }
    });
    $$renderer2.push(`<!----> Tailwind + Uikit</div></div></div> <div class="flex flex-col items-center gap-6 xl:flex-row">`);
    if (toggleValueForCodeCompare) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="mockup-code border-base-content/10 text-base-content relative max-w-[calc(100vw-2rem)] grow border bg-transparent text-xs xl:h-[550px]"><pre class="w-full whitespace-pre-wrap px-6 before:hidden"><code></code>&lt;div class="<span class="text-teal-700">card bg-base-200 w-80</span>">
		&lt;div class="<span class="text-teal-700">card-body</span>">
		  &lt;Textfield placeholder="Email"  />
		  &lt;Switch label="Accept terms of use"  />
		  &lt;Switch label="Submit to newsletter"  />
		  &lt;Button color="natural" >Save&lt;/Button>
		&lt;/div>
	  &lt;/div></pre></div> <div class="divider xl:divider-horizontal"><span class="hidden rtl:rotate-180 xl:inline">→</span> <span class="xl:hidden">↓</span></div> <div><div class="card bg-base-200 w-80 svelte-ovge82"><div class="card-body svelte-ovge82">`);
      TextField($$renderer2, { placeholder: "Email" });
      $$renderer2.push(`<!----> `);
      Switch($$renderer2, { label: "Accept terms of use" });
      $$renderer2.push(`<!----> `);
      Switch($$renderer2, { label: "Submit to newsletter" });
      $$renderer2.push(`<!----> `);
      Button($$renderer2, {
        color: "natural",
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Save`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="mockup-code border-base-content/10 text-base-content relative max-w-[calc(100vw-2rem)] grow border bg-transparent text-xs xl:h-[550px]"><pre class="w-full whitespace-pre-wrap px-6 before:hidden"><code></code>&lt;div class="<span class="text-rose-600">w-80 rounded-2xl bg-gray-100</span>">
		&lt;div class="<span class="text-rose-600">flex flex-col gap-2 p-8</span>">
		  &lt;input placeholder="Email" class="<span class="text-rose-600">w-full rounded-lg border border-gray-300 bg-white px-4 py-3 focus:outline-hidden focus:ring-2 focus:ring-gray-700 focus:ring-offset-2 focus:ring-offset-gray-100</span>" />
		  &lt;label class="<span class="text-rose-600">flex cursor-pointer items-center justify-between p-1</span>">
			Accept terms of use
			&lt;div class="<span class="text-rose-600">relative inline-block</span>">
			  &lt;input type="checkbox" class="<span class="text-rose-600">peer h-6 w-12 cursor-pointer appearance-none rounded-full border border-gray-300 bg-white checked:border-gray-900 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-gray-900 focus-visible:ring-offset-2</span>" />
			  &lt;span class="<span class="text-rose-600">pointer-events-none absolute start-1 top-1 block h-4 w-4 rounded-full bg-gray-400 transition-all duration-200 peer-checked:start-7 peer-checked:bg-gray-900</span>">&lt;/span>
			&lt;/div>
		  &lt;/label>
		  &lt;label class="<span class="text-rose-600">flex cursor-pointer items-center justify-between p-1</span>">
			Submit to newsletter
			&lt;div class="<span class="text-rose-600">relative inline-block</span>">
			  &lt;input type="checkbox" class="<span class="text-rose-600">peer h-6 w-12 cursor-pointer appearance-none rounded-full border border-gray-300 bg-white checked:border-gray-900 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-gray-900 focus-visible:ring-offset-2</span>" />
			  &lt;span class="<span class="text-rose-600">pointer-events-none absolute start-1 top-1 block h-4 w-4 rounded-full bg-gray-400 transition-all duration-200 peer-checked:start-7 peer-checked:bg-gray-900</span>">&lt;/span>
			&lt;/div>
		  &lt;/label>
		  &lt;button class="<span class="text-rose-600">inline-block cursor-pointer rounded-md bg-gray-700 px-4 py-3.5 text-center text-sm font-semibold uppercase text-white transition duration-200 ease-in-out hover:bg-gray-800 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-gray-700 focus-visible:ring-offset-2 active:scale-95</span>">Save&lt;/button>
		&lt;/div>
	  &lt;/div></pre></div> <div class="divider xl:divider-horizontal"><span class="hidden rtl:rotate-180 xl:inline">→</span> <span class="xl:hidden">↓</span></div> <div><div class="w-80 rounded-2xl bg-gray-100 text-black"><div class="flex flex-col gap-2 p-8"><input name="sample-email" placeholder="Email" class="w-full rounded-lg border border-gray-300 bg-white px-4 py-3 focus:outline-hidden focus:ring-2 focus:ring-gray-700 focus:ring-offset-2 focus:ring-offset-gray-100"/> <label class="flex cursor-pointer items-center justify-between p-1">Accept terms of use <div class="relative inline-block"><input name="sample-checkbox" type="checkbox" class="peer h-6 w-12 cursor-pointer appearance-none rounded-full border border-gray-300 bg-white checked:border-gray-900 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-gray-900 focus-visible:ring-offset-2"/> <span class="pointer-events-none absolute start-1 top-1 block h-4 w-4 rounded-full bg-gray-400 transition-all duration-200 peer-checked:start-7 peer-checked:bg-gray-900"></span></div></label> <label class="flex cursor-pointer items-center justify-between p-1">Submit to newsletter <span class="relative inline-block"><input type="checkbox" name="sample-checkbox" class="peer h-6 w-12 cursor-pointer appearance-none rounded-full border border-gray-300 bg-white checked:border-gray-900 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-gray-900 focus-visible:ring-offset-2"/> <span class="pointer-events-none absolute start-1 top-1 block h-4 w-4 rounded-full bg-gray-400 transition-all duration-200 peer-checked:start-7 peer-checked:bg-gray-900"></span></span></label> <button class="inline-block cursor-pointer rounded-md bg-gray-700 px-4 py-3.5 text-center text-sm font-semibold uppercase text-white transition duration-200 ease-in-out hover:bg-gray-800 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-gray-700 focus-visible:ring-offset-2 active:scale-95">Save</button></div></div></div>`);
    }
    $$renderer2.push(`<!--]--></div></div></div></div></div></div>`);
  }
  do {
    $$settled = true;
    $$inner_renderer = $$renderer.copy();
    $$render_inner($$inner_renderer);
  } while (!$$settled);
  $$renderer.subsume($$inner_renderer);
}
function _page($$renderer) {
  head("1uha8ag", $$renderer, ($$renderer2) => {
    $$renderer2.title(($$renderer3) => {
      $$renderer3.push(`<title>Svelte Uikit</title>`);
    });
    $$renderer2.push(`<meta name="description" content="svelte open source library. sveltejs + tailwindcss + daisyui "/>`);
  });
  HomePage($$renderer);
}
export {
  _page as default
};
