const __variableDynamicImportRuntimeHelper = (glob$1, path$13, segs) => {
  const v = glob$1[path$13];
  if (v) return typeof v === "function" ? v() : Promise.resolve(v);
  return new Promise((_, reject) => {
    (typeof queueMicrotask === "function" ? queueMicrotask : setTimeout)(reject.bind(null, /* @__PURE__ */ new Error("Unknown variable dynamic import: " + path$13 + (path$13.split("/").length !== segs ? ". Note that variables only represent file names one level deep." : ""))));
  });
};
async function load({ params }) {
  const content = await __variableDynamicImportRuntimeHelper(/* @__PURE__ */ Object.assign({ "../button.md": () => import("../../../../../chunks/button2.js") }), `../${params.slug}.md`, 2);
  return {
    content
  };
}
export {
  load
};
