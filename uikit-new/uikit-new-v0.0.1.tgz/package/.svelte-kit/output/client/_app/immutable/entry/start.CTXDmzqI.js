import{l as o,a as r}from"../chunks/CKAGc0J7.js";export{o as load_css,r as start};
