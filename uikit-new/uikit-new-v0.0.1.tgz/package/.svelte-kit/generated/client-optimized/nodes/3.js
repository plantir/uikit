import * as universal from "../../../../src/routes/docs/components/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/docs/components/[slug]/+page.svelte";