
// this file is generated — do not edit it


/// <reference types="@sveltejs/kit" />

/**
 * Environment variables [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env`. Like [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), this module cannot be imported into client-side code. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * _Unlike_ [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), the values exported from this module are statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * ```ts
 * import { API_KEY } from '$env/static/private';
 * ```
 * 
 * Note that all environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * 
 * ```
 * MY_FEATURE_FLAG=""
 * ```
 * 
 * You can override `.env` values from the command line like so:
 * 
 * ```sh
 * MY_FEATURE_FLAG="enabled" npm run dev
 * ```
 */
declare module '$env/static/private' {
	export const MAIL: string;
	export const USER: string;
	export const npm_config_version_commit_hooks: string;
	export const npm_config_user_agent: string;
	export const XDG_SEAT: string;
	export const npm_package_dependencies_flatpickr: string;
	export const npm_config_bin_links: string;
	export const BUN_INSTALL: string;
	export const GIT_ASKPASS: string;
	export const XDG_SESSION_TYPE: string;
	export const npm_node_execpath: string;
	export const npm_package_dependencies__tailwindcss_vite: string;
	export const npm_package_devDependencies_vite: string;
	export const npm_package_devDependencies__sveltejs_vite_plugin_svelte: string;
	export const npm_config_init_version: string;
	export const SHLVL: string;
	export const npm_package_files_0: string;
	export const CHROME_DESKTOP: string;
	export const HOME: string;
	export const LESS: string;
	export const MOTD_SHOWN: string;
	export const OLDPWD: string;
	export const OPENAI_BASE_URL: string;
	export const npm_package_files_1: string;
	export const TERM_PROGRAM_VERSION: string;
	export const npm_package_files_2: string;
	export const CLOCKIFY_API_KEY: string;
	export const LSCOLORS: string;
	export const ZSH: string;
	export const npm_package_scripts_prepack: string;
	export const npm_config_init_license: string;
	export const OPENAI_API_KEY: string;
	export const PAGER: string;
	export const VSCODE_GIT_ASKPASS_MAIN: string;
	export const npm_package_devDependencies_svelte_check: string;
	export const npm_config_version_tag_prefix: string;
	export const VSCODE_GIT_ASKPASS_NODE: string;
	export const npm_package_scripts_check: string;
	export const DBUS_SESSION_BUS_ADDRESS: string;
	export const npm_package_keywords_0: string;
	export const npm_package_exports___svelte: string;
	export const npm_config_engine_strict: string;
	export const COLORTERM: string;
	export const npm_package_description: string;
	export const npm_package_devDependencies_typescript: string;
	export const VOLTA_HOME: string;
	export const _VOLTA_TOOL_RECURSION: string;
	export const npm_package_readmeFilename: string;
	export const npm_package_types: string;
	export const npm_package_devDependencies_prettier: string;
	export const npm_package_sideEffects_0: string;
	export const npm_package_scripts_dev: string;
	export const LOGNAME: string;
	export const npm_package_type: string;
	export const _: string;
	export const npm_package_scripts_check_watch: string;
	export const CLOCKIFY_USER_ID: string;
	export const USER_ZDOTDIR: string;
	export const XDG_SESSION_CLASS: string;
	export const npm_package_scripts_lint: string;
	export const npm_package_scripts_prepare: string;
	export const npm_config_registry: string;
	export const TERM: string;
	export const XDG_SESSION_ID: string;
	export const npm_package_dependencies_mdsvex: string;
	export const npm_package_devDependencies_publint: string;
	export const npm_config_ignore_scripts: string;
	export const WINDOWPATH: string;
	export const npm_package_peerDependencies_svelte: string;
	export const PATH: string;
	export const NODE: string;
	export const npm_package_name: string;
	export const GDK_BACKEND: string;
	export const XDG_RUNTIME_DIR: string;
	export const DISPLAY: string;
	export const LANG: string;
	export const VSCODE_INJECTION: string;
	export const npm_package_devDependencies__sveltejs_package: string;
	export const LS_COLORS: string;
	export const TERM_PROGRAM: string;
	export const VSCODE_GIT_IPC_HANDLE: string;
	export const XAUTHORITY: string;
	export const npm_lifecycle_script: string;
	export const ORIGINAL_XDG_CURRENT_DESKTOP: string;
	export const npm_package_devDependencies__sveltejs_kit: string;
	export const npm_config_version_git_message: string;
	export const SHELL: string;
	export const npm_lifecycle_event: string;
	export const npm_package_version: string;
	export const NO_AT_BRIDGE: string;
	export const npm_config_argv: string;
	export const npm_package_dependencies_lodash_es: string;
	export const npm_package_devDependencies_svelte: string;
	export const npm_package_scripts_build: string;
	export const npm_package_svelte: string;
	export const npm_package_scripts_prepublishOnly: string;
	export const npm_config_version_git_tag: string;
	export const npm_config_version_git_sign: string;
	export const npm_package_license: string;
	export const npm_config_strict_ssl: string;
	export const VSCODE_GIT_ASKPASS_EXTRA_ARGS: string;
	export const XDG_VTNR: string;
	export const npm_package_scripts_format: string;
	export const LC_ALL: string;
	export const PWD: string;
	export const npm_execpath: string;
	export const CLOCKIFY_WORKSPACE_ID: string;
	export const ZDOTDIR: string;
	export const npm_package_exports___types: string;
	export const npm_package_devDependencies__sveltejs_adapter_auto: string;
	export const npm_config_save_prefix: string;
	export const npm_config_ignore_optional: string;
	export const npm_package_dependencies_mdsvexamples: string;
	export const npm_package_devDependencies_prettier_plugin_svelte: string;
	export const npm_package_scripts_preview: string;
	export const npm_package_dependencies_tailwindcss: string;
	export const npm_package_dependencies_daisyui: string;
	export const INIT_CWD: string;
	export const NODE_ENV: string;
}

/**
 * Similar to [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private), except that it only includes environment variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Values are replaced statically at build time.
 * 
 * ```ts
 * import { PUBLIC_BASE_URL } from '$env/static/public';
 * ```
 */
declare module '$env/static/public' {
	
}

/**
 * This module provides access to runtime environment variables, as defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * This module cannot be imported into client-side code.
 * 
 * ```ts
 * import { env } from '$env/dynamic/private';
 * console.log(env.DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 * 
 * > [!NOTE] In `dev`, `$env/dynamic` always includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 */
declare module '$env/dynamic/private' {
	export const env: {
		MAIL: string;
		USER: string;
		npm_config_version_commit_hooks: string;
		npm_config_user_agent: string;
		XDG_SEAT: string;
		npm_package_dependencies_flatpickr: string;
		npm_config_bin_links: string;
		BUN_INSTALL: string;
		GIT_ASKPASS: string;
		XDG_SESSION_TYPE: string;
		npm_node_execpath: string;
		npm_package_dependencies__tailwindcss_vite: string;
		npm_package_devDependencies_vite: string;
		npm_package_devDependencies__sveltejs_vite_plugin_svelte: string;
		npm_config_init_version: string;
		SHLVL: string;
		npm_package_files_0: string;
		CHROME_DESKTOP: string;
		HOME: string;
		LESS: string;
		MOTD_SHOWN: string;
		OLDPWD: string;
		OPENAI_BASE_URL: string;
		npm_package_files_1: string;
		TERM_PROGRAM_VERSION: string;
		npm_package_files_2: string;
		CLOCKIFY_API_KEY: string;
		LSCOLORS: string;
		ZSH: string;
		npm_package_scripts_prepack: string;
		npm_config_init_license: string;
		OPENAI_API_KEY: string;
		PAGER: string;
		VSCODE_GIT_ASKPASS_MAIN: string;
		npm_package_devDependencies_svelte_check: string;
		npm_config_version_tag_prefix: string;
		VSCODE_GIT_ASKPASS_NODE: string;
		npm_package_scripts_check: string;
		DBUS_SESSION_BUS_ADDRESS: string;
		npm_package_keywords_0: string;
		npm_package_exports___svelte: string;
		npm_config_engine_strict: string;
		COLORTERM: string;
		npm_package_description: string;
		npm_package_devDependencies_typescript: string;
		VOLTA_HOME: string;
		_VOLTA_TOOL_RECURSION: string;
		npm_package_readmeFilename: string;
		npm_package_types: string;
		npm_package_devDependencies_prettier: string;
		npm_package_sideEffects_0: string;
		npm_package_scripts_dev: string;
		LOGNAME: string;
		npm_package_type: string;
		_: string;
		npm_package_scripts_check_watch: string;
		CLOCKIFY_USER_ID: string;
		USER_ZDOTDIR: string;
		XDG_SESSION_CLASS: string;
		npm_package_scripts_lint: string;
		npm_package_scripts_prepare: string;
		npm_config_registry: string;
		TERM: string;
		XDG_SESSION_ID: string;
		npm_package_dependencies_mdsvex: string;
		npm_package_devDependencies_publint: string;
		npm_config_ignore_scripts: string;
		WINDOWPATH: string;
		npm_package_peerDependencies_svelte: string;
		PATH: string;
		NODE: string;
		npm_package_name: string;
		GDK_BACKEND: string;
		XDG_RUNTIME_DIR: string;
		DISPLAY: string;
		LANG: string;
		VSCODE_INJECTION: string;
		npm_package_devDependencies__sveltejs_package: string;
		LS_COLORS: string;
		TERM_PROGRAM: string;
		VSCODE_GIT_IPC_HANDLE: string;
		XAUTHORITY: string;
		npm_lifecycle_script: string;
		ORIGINAL_XDG_CURRENT_DESKTOP: string;
		npm_package_devDependencies__sveltejs_kit: string;
		npm_config_version_git_message: string;
		SHELL: string;
		npm_lifecycle_event: string;
		npm_package_version: string;
		NO_AT_BRIDGE: string;
		npm_config_argv: string;
		npm_package_dependencies_lodash_es: string;
		npm_package_devDependencies_svelte: string;
		npm_package_scripts_build: string;
		npm_package_svelte: string;
		npm_package_scripts_prepublishOnly: string;
		npm_config_version_git_tag: string;
		npm_config_version_git_sign: string;
		npm_package_license: string;
		npm_config_strict_ssl: string;
		VSCODE_GIT_ASKPASS_EXTRA_ARGS: string;
		XDG_VTNR: string;
		npm_package_scripts_format: string;
		LC_ALL: string;
		PWD: string;
		npm_execpath: string;
		CLOCKIFY_WORKSPACE_ID: string;
		ZDOTDIR: string;
		npm_package_exports___types: string;
		npm_package_devDependencies__sveltejs_adapter_auto: string;
		npm_config_save_prefix: string;
		npm_config_ignore_optional: string;
		npm_package_dependencies_mdsvexamples: string;
		npm_package_devDependencies_prettier_plugin_svelte: string;
		npm_package_scripts_preview: string;
		npm_package_dependencies_tailwindcss: string;
		npm_package_dependencies_daisyui: string;
		INIT_CWD: string;
		NODE_ENV: string;
		[key: `PUBLIC_${string}`]: undefined;
		[key: `${string}`]: string | undefined;
	}
}

/**
 * Similar to [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), but only includes variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Note that public dynamic environment variables must all be sent from the server to the client, causing larger network requests — when possible, use `$env/static/public` instead.
 * 
 * ```ts
 * import { env } from '$env/dynamic/public';
 * console.log(env.PUBLIC_DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 */
declare module '$env/dynamic/public' {
	export const env: {
		[key: `PUBLIC_${string}`]: string | undefined;
	}
}
